import React, {useRef, useEffect} from 'react'
import * as THREE from 'three'
export default function VanScene({onSelect, config}){
  // build simple van interior with seats and floor as meshes
  const groupRef = React.useRef()
  useEffect(()=>{
    // set materials based on config
    const g = groupRef.current
    if(!g) return
    g.traverse(child=>{
      if(child.isMesh){
        const matName = child.name
        const cfg = config[matName]
        if(cfg){
          if(cfg.color){
            child.material.color = new THREE.Color(cfg.color)
          }
          if(cfg.texture){
            const loader = new THREE.TextureLoader()
            const tex = loader.load('/textures/'+cfg.texture)
            tex.wrapS = tex.wrapT = THREE.RepeatWrapping
            tex.repeat.set(1,1)
            child.material.map = tex
            child.material.needsUpdate = true
          } else {
            child.material.map = null
          }
        }
      }
    })
  }, [config])
  const handleClick = (e)=>{
    e.stopPropagation()
    if(onSelect && e.object) onSelect(e.object.name)
  }
  return (
    <group ref={groupRef} rotation={[0,Math.PI,0]} onClick={handleClick}>
      {/* floor */}
      <mesh name="FloorMaterial" position={[0,0,0]} receiveShadow>
        <boxGeometry args={[6,0.1,3]} />
        <meshStandardMaterial color={'#bda78b'} />
      </mesh>
      {/* left bench seat at rear */}
      <mesh name="SideSeat" position={[-1.8,0.5,-0.6]} onClick={handleClick}>
        <boxGeometry args={[1.2,0.8,0.6]} />
        <meshStandardMaterial color={'#5b6b72'} />
      </mesh>
      {/* driver-like seat pair */}
      <mesh name="SeatMaterial" position={[0.8,0.5,0.2]} onClick={handleClick}>
        <boxGeometry args={[0.9,0.9,0.9]} />
        <meshStandardMaterial color={'#a0522d'} />
      </mesh>
      <mesh name="SeatMaterial2" position={[1.8,0.5,0.2]} onClick={handleClick}>
        <boxGeometry args={[0.9,0.9,0.9]} />
        <meshStandardMaterial color={'#a0522d'} />
      </mesh>
      {/* back wall */}
      <mesh position={[0,1.2,-1.45]} receiveShadow>
        <boxGeometry args={[6,1.6,0.1]} />
        <meshStandardMaterial color={'#303030'} />
      </mesh>
      {/* ceiling with LED strip */}
      <mesh name="Ceiling" position={[0,1.6,0]}>
        <boxGeometry args={[6,0.1,3]} />
        <meshStandardMaterial color={'#0a2a6a'} />
      </mesh>
      {/* LED strips as emissive planes */}
      <mesh name="LedStrip1" position={[0,1.56,0.4]} rotation={[0,0,0]}>
        <boxGeometry args={[4,0.02,0.08]} />
        <meshStandardMaterial emissive={'#0055ff'} emissiveIntensity={1} color={'#000'} />
      </mesh>
      <mesh name="LedStrip2" position={[0,1.56,-0.4]} rotation={[0,0,0]}>
        <boxGeometry args={[4,0.02,0.08]} />
        <meshStandardMaterial emissive={'#0055ff'} emissiveIntensity={1} color={'#000'} />
      </mesh>
      {/* windows */}
      <mesh position={[2.9,0.9,0]} rotation={[0,Math.PI/2,0]}>
        <boxGeometry args={[0.1,0.8,2.4]} />
        <meshStandardMaterial color={'#0b1a25'} transparent opacity={0.25} />
      </mesh>
    </group>
  )
}
