import React from 'react'
export default function ControlsPanel({selected,setConfig,config}){
  if(!selected) return (
    <div style={{background:'rgba(0,0,0,0.5)',padding:12,borderRadius:8,color:'#ddd',minWidth:260}}>
      <div style={{fontWeight:700}}>Personalização</div>
      <div style={{fontSize:13,marginTop:8}}>Clique em um componente no modelo para editar.</div>
    </div>
  )
  const current = config[selected] || {color:'#ffffff',texture:null}
  const changeColor = (e)=> setConfig({...config, [selected]: {...current, color:e.target.value}})
  const setTexture = (tex)=> setConfig({...config, [selected]: {...current, texture:tex}})
  return (
    <div style={{background:'rgba(0,0,0,0.6)',padding:12,borderRadius:8,color:'#fff',minWidth:260}}>
      <div style={{fontWeight:700}}>Editar - {selected}</div>
      <div style={{marginTop:8}}>Cor:</div>
      <input type="color" value={current.color} onChange={changeColor} style={{width:'100%',height:36,borderRadius:6}} />
      <div style={{marginTop:8}}>Texturas:</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginTop:6}}>
        {['leather_brown.jpg','seat_pattern.jpg','floor_wood.jpg','ceiling_blue.jpg'].map(t=> (
          <img key={t} src={`/textures/${t}`} alt={t} style={{width:'100%',borderRadius:6,cursor:'pointer'}} onClick={()=>setTexture(t)} />
        ))}
      </div>
      <div style={{marginTop:10,display:'flex',gap:8}}>
        <button onClick={()=>setConfig({...config, [selected]: {color:'#ffffff', texture:null}})}>Reset</button>
      </div>
    </div>
  )
}
