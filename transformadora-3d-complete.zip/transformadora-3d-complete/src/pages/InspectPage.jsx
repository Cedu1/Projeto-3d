import React, {useState, useEffect} from 'react'
export default function InspectPage(){
  const [info, setInfo] = useState(null)
  const handleFile = async (e)=>{
    const file = e.target.files[0]; if(!file) return
    const url = URL.createObjectURL(file)
    setInfo({name:file.name, size:file.size})
  }
  return (
    <div style={{padding:20,color:'#ddd'}}>
      <h2>Inspecionar .glb</h2>
      <input type="file" accept='.glb,.gltf' onChange={handleFile} />
      {info && <div style={{marginTop:12}}><b>Arquivo:</b> {info.name} <br/> <b>Tamanho:</b> {Math.round(info.size/1024)} KB</div>}
      <p style={{marginTop:12}}>Use a aba 'Inspecionar .glb' para verificar arquivos .glb (lista básica).</p>
    </div>
  )
}