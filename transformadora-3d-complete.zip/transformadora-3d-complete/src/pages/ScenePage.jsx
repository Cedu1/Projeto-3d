import React, {useState} from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Stage } from '@react-three/drei'
import VanScene from '../scene/VanScene'
import ControlsPanel from '../scene/ControlsPanel'
export default function ScenePage({mode}){
  const [selected, setSelected] = useState(null)
  const [config, setConfig] = useState({
    SeatMaterial: { color:'#a0522d', texture:'leather_brown.jpg' },
    SideSeat: { color:'#5b6b72', texture:'seat_pattern.jpg' },
    FloorMaterial: { color:'#bda78b', texture:'floor_wood.jpg' },
    Ceiling: { color:'#0a2a6a', texture:'ceiling_blue.jpg' }
  })
  return (
    <div style={{width:'100%',height:'100%'}}>
      <div style={{position:'absolute',right:18,top:18,zIndex:40,display:'flex',flexDirection:'column',gap:8}}>
        <div style={{background:'rgba(0,0,0,0.5)',padding:10,borderRadius:8}}>
          <div style={{fontSize:14,fontWeight:600}}>Parte:</div>
          <div style={{marginTop:6}}>{selected||'Nenhuma'}</div>
        </div>
      </div>
      <Canvas camera={{position:[4,2.2,6],fov:45}}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[10,10,5]} intensity={1.2} />
        <Stage environment="warehouse" intensity={0.8}>
          <VanScene onSelect={setSelected} config={config} />
        </Stage>
        <OrbitControls />
      </Canvas>
      <div style={{position:'absolute',left:18,bottom:18,zIndex:40}}>
        <ControlsPanel selected={selected} setConfig={setConfig} config={config} />
      </div>
    </div>
  )
}
