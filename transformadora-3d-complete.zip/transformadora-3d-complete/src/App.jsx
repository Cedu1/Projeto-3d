import React, {useState} from 'react'
import ScenePage from './pages/ScenePage'
import InspectPage from './pages/InspectPage'

export default function App(){
  const [page, setPage] = useState('scene')
  return (
    <div className="app">
      <div className="sidebar">
        <div className="logo">ACA Transformadora - Visualização 3D</div>
        <div className="menu">
          <button className={page==='scene'?'active':''} onClick={()=>setPage('scene')}>Visualização 3D</button>
          <button className={page==='before'?'active':''} onClick={()=>setPage('before')}>Antes / Depois</button>
          <button className={page==='internal'?'active':''} onClick={()=>setPage('internal')}>Visualização Interna</button>
          <button className={page==='inspect'?'active':''} onClick={()=>setPage('inspect')}>Inspecionar .glb</button>
        </div>
        <div className="shareBox">
          <div style={{fontSize:12,color:'#9aa0a6'}}>Projeto de demonstração</div>
          <div style={{marginTop:8}}><button style={{width:'100%',padding:8,borderRadius:6}}>Salvar Projeto</button></div>
        </div>
        <div className="controls">
          <div style={{fontSize:13,color:'#9aa0a6'}}>Dicas</div>
          <div style={{fontSize:12,color:'#bdbdbf',marginTop:6}}>Clique nas partes do modelo para editar cor ou textura.</div>
        </div>
      </div>
      <div className="canvasWrap">
        <div className="header">Visualização 3D</div>
        {page==='scene' && <ScenePage/>}
        {page==='before' && <ScenePage mode="before" />}
        {page==='internal' && <ScenePage mode="internal" />}
        {page==='inspect' && <InspectPage/>}
      </div>
    </div>
  )
}