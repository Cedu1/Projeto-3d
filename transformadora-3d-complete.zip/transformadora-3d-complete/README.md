Projeto: Transformadora 3D - Demo (React + Three.js)
=======================================================

Conteúdo do zip:
- Projeto React + Vite pronto para rodar.
- Sidebar com botões (Visualização 3D, Antes/Depois, Visualização Interna, Inspecionar .glb).
- Cena de exemplo que simula o interior de uma van (geometrias placeholder) with LED, bancos and floor.
- Texturas de exemplo in public/textures/ (images for demo).
- public/models/ for your sprinter.glb file

How to run:
1) Extract zip.
2) In terminal: npm install && npm run dev
3) Open http://localhost:5173

Replace with real model:
- Put sprinter.glb in public/models/sprinter.glb
- Name materials in Blender for direct mapping (SeatMaterial, FloorMaterial, Ceiling, LedStrip)
- Pack textures in Blender before exporting .glb (File -> External Data -> Pack Resources)

Notes:
- This demo uses simple boxes to simulate the van interior. Replace with a .glb for realistic visuals.
- Optimize assets for production (gltfpack/draco, serve compressed files).
