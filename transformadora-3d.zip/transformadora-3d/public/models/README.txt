Coloque aqui seu modelo 3D nomeado 'modelo.glb' ou 'modelo.gltf'. Ex: /public/models/modelo.glb
Se não houver modelo, o app mostrará um placeholder (bloco).