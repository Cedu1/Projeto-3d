Transformadora-3d - Projeto pronto para GitHub Pages

Como usar:
1. Extraia o zip.
2. Se quiser testar com seu modelo, coloque o arquivo GLB em: public/models/modelo.glb
3. Para desenvolvimento (opcional):
   - npm install
   - npm run dev
4. Para publicar no GitHub Pages (opção simples):
   - Faça push do projeto para um repositório chamado 'transformadora-3d'
   - No GitHub, ative Pages para a branch 'main' e configure ou use action para publicar o site.
   - O arquivo 'vite.config.js' já tem base '/transformadora-3d/' para GitHub Pages.
Observações:
- Caso não haja /public/models/modelo.glb, a página exibirá um modelo placeholder (caixa).
- Substitua modelo e texturas pelos seus arquivos para ver o interior real da van.

Feito para você - pronto para ajustar o modelo depois.