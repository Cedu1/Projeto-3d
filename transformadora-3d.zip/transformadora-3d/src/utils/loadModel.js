import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
export function loadModel(url, onLoad, onError){
  const loader = new GLTFLoader();
  loader.load(url,onLoad,undefined,onError);
}