import React, { useRef, useEffect } from 'react'
import { useGLTF } from '@react-three/drei'
import * as THREE from 'three'

export default function VanModel({ onError }){
  const ref = useRef()
  let gltf = null
  try {
    gltf = useGLTF('/models/modelo.glb')
  } catch (e) {
    // loader will throw during suspense; we'll handle in useEffect
  }

  useEffect(()=>{
    // no-op
  }, [])

  if(!gltf){
    // fallback placeholder
    return (
      <group>
        <mesh position={[0,0.6,0]}>
          <boxGeometry args={[3,1.2,1.6]} />
          <meshStandardMaterial color={'#a0522d'} />
        </mesh>
        <mesh position={[0,0.05,0]} rotation={[-Math.PI/2,0,0]}>
          <planeGeometry args={[6,4]} />
          <meshStandardMaterial map={new THREE.TextureLoader().load('/textures/placeholder.jpg')} />
        </mesh>
      </group>
    )
  }

  return <primitive object={gltf.scene} dispose={null} />
}

useGLTF.preload('/models/modelo.glb')