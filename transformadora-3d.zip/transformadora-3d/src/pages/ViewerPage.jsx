import React, { useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Stage } from '@react-three/drei'
import VanModel from '../scene/VanModel'

export default function ViewerPage(){
  const [error, setError] = useState(null)
  return (
    <div style={{width:'100%',height:'100%'}}>
      <Canvas camera={{position:[4,2,6],fov:50}}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5,5,5]} intensity={1} />
        <Stage environment='warehouse' intensity={0.6}>
          <VanModel onError={setError} />
        </Stage>
        <OrbitControls />
      </Canvas>
      {error && <div style={{position:'absolute',left:16,top:80,background:'#fff',padding:8,borderRadius:6,border:'1px solid #ddd'}}>{error}</div>}
      <div className="controlsBox">Clique em uma parte para editar (futuro)</div>
    </div>
  )
}