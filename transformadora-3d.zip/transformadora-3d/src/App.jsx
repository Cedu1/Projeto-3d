import React from 'react'
import ViewerPage from './pages/ViewerPage'

export default function App(){
  return (
    <div>
      <header className="header">
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{fontWeight:700}}>ACA Transformadora 3D</div>
          <div style={{opacity:0.7}}>Monte sua van personalizada em 3D</div>
        </div>
      </header>
      <div className="container">
        <div className="sidebar">
          <div className="logo">transformadora-3d</div>
          <div style={{fontSize:13,color:'#555'}}>Use os controles para girar o modelo. Para testar, coloque seu modelo em /public/models/modelo.glb</div>
          <button className="button" onClick={()=>window.location.reload()}>Recarregar</button>
        </div>
        <div className="canvasWrap">
          <ViewerPage />
        </div>
      </div>
    </div>
  )
}